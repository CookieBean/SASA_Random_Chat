pip install -r requirements.txt

해당 커맨드를 이용해서 실행에 필요한 라이브러리들을 다운로드 받을 수 있습니다!
(Mac의 경우 미리 만들어진 venv를 active하여 새로 라이브러리들을 다운로드할 필요 없이 설치할 수 있습니다)

<Mac>

1.
source ./venv/bin/activate
or
. ./venv/bin/activate

2.
python main.py


